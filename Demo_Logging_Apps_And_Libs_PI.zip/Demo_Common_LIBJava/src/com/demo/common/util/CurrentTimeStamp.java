package com.demo.common.util;

import java.text.SimpleDateFormat;
import java.util.*;

public class CurrentTimeStamp {
	
	public static String getTimeStamp()
   {
		return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new Date());
    }		

}