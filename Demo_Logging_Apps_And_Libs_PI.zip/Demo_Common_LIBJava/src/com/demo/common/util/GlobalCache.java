package com.demo.common.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbGlobalMap;
import com.ibm.broker.plugin.MbGlobalMapSessionPolicy;

/**
* The GlobalCache program uses com.ibm.broker.plugin.MbGlobalMap and com.ibm.broker.plugin.MbGlobalMapSessionPolicy to 
* load new keys to the Global Cache or to update and delete existing keys in the Global Cache 
*
* @author  James Berube, Ram Damisetty
* @version 1.0
* @since   04-27-2018
* @update  07-21-2018 
*/

public class GlobalCache {
	
	/**
	 * 
	 * @param mapName
	 * @param key
	 * @return true if key exists in the IBM Broker Global Cache, otherwise false
	 */
	public static Boolean keyExists(String mapName, String key) {
		try{			
			return (Boolean) MbGlobalMap.getGlobalMap(mapName).containsKey(key);
		} catch (MbException mbe) {
			return false;
		} 
	}
	
	/**
	 * 
	 * @param mapName
	 * @param key
	 * @param val
	 * @return true if the key is saved to IBM Broker Global Cache, otherwise false
	 */
	public static Boolean saveKeyValue(String mapName, String key, String val) {
		try{
			MbGlobalMap.getGlobalMap(mapName).put(key, val);			
			return (true);				
		} catch (MbException mbe) {
			// Duplicate insert to cache...ignoring	
			return false;
		} 
	}
	
	/**
	 * 
	 * @param mapName
	 * @param key
	 * @param val
	 * @param timeToLive
	 		- timeToLive - - int This is a period of time, in seconds. Cache entries created by a MbGlobalMap object will automatically be evicted from the cache when this period of time (since the last update of that data) has elapsed.
	 		- public MbGlobalMapSessionPolicy(int timeToLive)
	 * @return true if the key is saved to IBM Broker Global Cache, otherwise false
	 */
	public static Boolean saveKeyValueTTL(String mapName, String key, String val, Long timeToLive) {
		try{
			MbGlobalMap.getGlobalMap(mapName, new MbGlobalMapSessionPolicy((int)(long)timeToLive)).put(key, val);			
			return (true);				
		} catch (MbException mbe) {
			// Duplicate insert to cache...ignoring	
			return false;
		} 
	}
	
	/**
	 * 
	 * @param mapName
	 * @param key
	 * @param val
	 * @return true if the key exists in and updated to IBM Broker Global Cache, otherwise false
	 */
	public static Boolean updateKeyValue(String mapName, String key, String val) {
		try{
			if ( (Boolean) MbGlobalMap.getGlobalMap(mapName).containsKey(key) ) {
				MbGlobalMap.getGlobalMap(mapName).update(key, val);
				return true;
			} else {
				return false;
			}				
		} catch (MbException mbe) {
			return false;
		} 
	}
	
	/**
	 * 
	 * @param mapName
	 * @param key
	 * @param val
	 * @param timeToLive
	 		- timeToLive - - int This is a period of time, in seconds. Cache entries created by a MbGlobalMap object will automatically be evicted from the cache when this period of time (since the last update of that data) has elapsed.
	 		- public MbGlobalMapSessionPolicy(int timeToLive)
	 * @return true if the key exists in and updated to IBM Broker Global Cache, otherwise false
	 */
	public static Boolean updateKeyValueTTL(String mapName, String key, String val, Long timeToLive) {
		try{
			if ( (Boolean) MbGlobalMap.getGlobalMap(mapName).containsKey(key) ) {
				MbGlobalMap.getGlobalMap(mapName, new MbGlobalMapSessionPolicy((int)(long)timeToLive)).update(key, val);
				return true;
			} else {
				return false;
			}				
		} catch (MbException mbe) {
			return false;
		} 
	}
	
	/**
	 * 
	 * @param mapName
	 * @param key
	 * @param val
	 * @return true if the key is saved to IBM Broker Global Cache whether the key exists or a new key, otherwise false
	 */
	public static Boolean saveOrUpdateKeyValue(String mapName, String key, String val) {
		try{
			if ( (Boolean) MbGlobalMap.getGlobalMap(mapName).containsKey(key) ) {
				MbGlobalMap.getGlobalMap(mapName).update(key, val);
				return true;
			} else {
				MbGlobalMap.getGlobalMap(mapName).put(key, val);
				return true;
			}				
		} catch (MbException mbe) {
			return false;
		} 
	}
	
	/**
	 * 
	 * @param mapName
	 * @param key
	 * @param val
	 * @param timeToLive
	 		- timeToLive - - int This is a period of time, in seconds. Cache entries created by a MbGlobalMap object will automatically be evicted from the cache when this period of time (since the last update of that data) has elapsed.
	 		- public MbGlobalMapSessionPolicy(int timeToLive)
	 * @return true if the key is saved to IBM Broker Global Cache whether the key exists or a new key, otherwise false
	 */
	public static Boolean saveOrUpdateKeyValueTTL(String mapName, String key, String val, Long ttl) {
		try{
			if ( (Boolean) MbGlobalMap.getGlobalMap(mapName).containsKey(key) ) {
				MbGlobalMap.getGlobalMap(mapName, new MbGlobalMapSessionPolicy((int)(long)ttl)).update(key, val);
				return true;
			} else {
				MbGlobalMap.getGlobalMap(mapName, new MbGlobalMapSessionPolicy((int)(long)ttl)).put(key, val);
				return true;
			}				
		} catch (MbException mbe) {
			return false;
		} 
	}
	
	/**
	 * 
	 * @param mapName
	 * @param key
	 * @return key's value if the key exists in the IBM Broker Global Cache, otherwise null or error details if exception occurs
	 */
	public static String getValue(String mapName, String key) {
		try{
			if ( (Boolean) MbGlobalMap.getGlobalMap(mapName).containsKey(key) ) {
				return (String) MbGlobalMap.getGlobalMap(mapName).get(key);
			} else {
				return null;
			}				
		} catch (MbException mbe) {
			return ("ERROR: " + mbe.toString());
		} 
	}
	
	/**
	 * 
	 * @param mapName
	 * @param key
	 * @return true if the key exists and deleted from the IBM Broker Global Cache, otherwise false
	 */
	public static Boolean deleteKey(String mapName, String key) {
		try{
			if ( (Boolean) MbGlobalMap.getGlobalMap(mapName).containsKey(key) ) {
				MbGlobalMap.getGlobalMap(mapName).remove(key);
				return true;
			} else {
				return false;
			}				
		} catch (MbException mbe) {
			return false;
		} 
	} 

//	public static String getValue(String strMapName, String strKey) {
//		
//		String strValue = null;
//		MbGlobalMap globalMap = null;
//		
//		try
//		{
//			globalMap = MbGlobalMap.getGlobalMap(strMapName);
//			strValue = (String) globalMap.get(strKey);
//		}
//		catch(MbException mbe)
//		{
//			System.out.println(mbe.getMessage());
//			mbe.printStackTrace();
//		}
//		catch(Exception ex)
//		{
//			System.out.println(ex.getMessage());
//			ex.printStackTrace();
//		}
//		
//		return strValue;
//	}
	
	/**
	 * Method to add all the key-value pairs for a map in Global Cache
	 */	
	
	public static Boolean addMap(MbElement elmMap) {
		
		String strValue = null;
		String strKey = null;
		String strMapName = null;
		MbGlobalMap globalMap = null;
		
		try
		{
			elmMap = elmMap.getFirstChild();
			strMapName = elmMap.getValueAsString();
			
			globalMap = MbGlobalMap.getGlobalMap(strMapName);
			
			MbElement elmEntry = elmMap.getNextSibling();
			
			while (elmEntry != null) {
				
				strKey = elmEntry.getFirstChild().getValueAsString();
				strValue = elmEntry.getValueAsString();
				
				if(globalMap.containsKey(strKey)) {
					
					globalMap.update(strKey,strValue);
				} else {
					globalMap.put(strKey, strValue);
				}
				
				elmEntry = elmEntry.getNextSibling();
			}
				
			
		}
		catch(MbException mbe) {
			System.out.println(mbe.getMessage());
			mbe.printStackTrace();
			return Boolean.FALSE;
		}		

		
		return Boolean.TRUE;
	}	
	/**@Author: Venku
	 * Method to get a List of parameters from Global Cache using map name and key.
	 * List of parameters stored as single Item in Global map using delimiters
	 *  Ex:  <Map name="ExceptionRegex">
     *         <Entry key="RegularExpressionList">valu1;valu2;value3</Entry>
     *       </Map>
     * This method accepts input params  
     *       strMapName - Map name (Ex: ExceptionRegex)
     *       strKey     - Key with which value stored in Map (Ex:RegularExpressionList)
     *       mbEnvironmentElement - Reference of Environment variable used to add and return params 
     * Step1: Lookup and retrieves string value using Mapname & Mapkey
     * Step2: process string value to split and convert in to ArrayList of values
     * Step3: Iterate over List and create MB element with name  strKey and value under provided  mbEnvironmentElement reference tree
     *  
	 */
	public static Boolean getParamList(String strMapName, String strKey,MbElement mbEnvironmentElement) {
		
		String strValue = null;
		List<String> paramValues = new ArrayList<String>();
		MbGlobalMap globalMap = null;
		
		try
		{
			globalMap = MbGlobalMap.getGlobalMap(strMapName);
			strValue = (String) globalMap.get(strKey);
			paramValues = new ArrayList<String>(Arrays.asList(strValue.split(";")));
			
			 for (String param : paramValues) {
				 mbEnvironmentElement.createElementAsLastChild(MbElement.TYPE_NAME_VALUE,strKey,param);
			   
			 }
			 
		}
		catch(MbException mbe)
		{
			System.out.println(mbe.getMessage());
			mbe.printStackTrace();
			return Boolean.FALSE;

		}
		catch(Exception ex)
		{
			System.out.println(ex.getMessage());
			ex.printStackTrace();
			return Boolean.FALSE;
		}
		
		return Boolean.TRUE;
	}
	
	/*** Method to get a List of parameters from Global Cache using map name and key.
	 * List of parameters stored as single Item in Global map using delimiters
	 *  Ex:  <Map name="ExceptionRegex">
     *         <Entry key="RegularExpressionList">valu1;valu2;value3</Entry>
     *       </Map>
     * This method accepts input params  
     *       strMapName - Map name (Ex: ExceptionRegex)
     *       strKey     - Key with which value stored in Map (Ex:RegularExpressionList)
     * Step1: Lookup and retrieves string value using Mapname & Mapkey
     * Step2: process string value to split and convert in to ArrayList of values and return list
     *  
	 */
	public static List<String> getParamList(String strMapName, String strKey) {
		
		String strValue = null;
		List<String> paramValues = new ArrayList<String>();
		MbGlobalMap globalMap = null;
		
		try
		{
			globalMap = MbGlobalMap.getGlobalMap(strMapName);
			strValue = (String) globalMap.get(strKey);
			paramValues = new ArrayList<String>(Arrays.asList(strValue.split(";")));
						 
		}
		catch(MbException mbe)
		{
			System.out.println(mbe.getMessage());
			mbe.printStackTrace();
			return paramValues;

		}
		catch(Exception ex)
		{
			System.out.println(ex.getMessage());
			ex.printStackTrace();
			return paramValues;
		}
		
		return paramValues;
	}
	
	
	/**
	 * Method to get a add a key-value pair to a map in Global Cache
	 */	
	
	public static Boolean addUpdateKey(String strMapName, String strKey, String strValue) {
		
		MbGlobalMap globalMap = null;
		
		try
		{
			// Get an existing Map, or create the dynamic map if it doesn't exist
			globalMap = MbGlobalMap.getGlobalMap(strMapName);
			
			// If key is not present, add the key-value pair to the map
			// If key exists, refresh the value of the key
			if(globalMap.containsKey(strKey)) {
				globalMap.update(strKey,strValue);
			} else {
				globalMap.put(strKey, strValue);
			}
		}
		catch(MbException mbe) {
			System.out.println(mbe.getMessage());
			mbe.printStackTrace();
			return Boolean.FALSE;
		}		
		
		return Boolean.TRUE;
	}	

}
